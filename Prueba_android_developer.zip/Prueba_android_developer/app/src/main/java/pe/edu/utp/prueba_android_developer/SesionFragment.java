package pe.edu.utp.prueba_android_developer;


import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Response.ErrorListener;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.JsonRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.Map;
import java.util.HashMap;

import static android.content.Context.MODE_PRIVATE;
import static android.provider.ContactsContract.CommonDataKinds.Website.URL;


public class SesionFragment extends Fragment implements Response.Listener<JSONObject>, ErrorListener {
    RequestQueue rq;
    JsonRequest jrq;
    EditText txtUser, txtPwd;
    Button btnSesion;
    CheckBox saveLoginCheckbox;
    private SharedPreferences loginPreferences;
    private SharedPreferences.Editor loginPrefsEditor;
    Boolean saveLogin;
    String username;
    String password;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        final View vista = inflater.inflate(R.layout.fragment_sesion, container, false);
        txtUser = (EditText) vista.findViewById(R.id.txtuser);
        txtPwd = (EditText) vista.findViewById(R.id.txtpwd);
        btnSesion = (Button) vista.findViewById(R.id.btnsesion);
        saveLoginCheckbox = vista.findViewById(R.id.saveLoginCheckbox);
        loginPreferences = getContext().getSharedPreferences("loginPrefs", MODE_PRIVATE);
        loginPrefsEditor = loginPreferences.edit();

        saveLogin = loginPreferences.getBoolean("saveLogin", false);
        if (saveLogin == true) {
            txtUser.setText(loginPreferences.getString("username", ""));
            txtPwd.setText(loginPreferences.getString("password", ""));
            saveLoginCheckbox.setChecked(true);
        }

        username = txtUser.getText().toString();
        password = txtPwd.getText().toString();


        rq = Volley.newRequestQueue(getContext());

        btnSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                username = txtUser.getText().toString();
                password = txtPwd.getText().toString();



                while (username != null || password != null) {

                    btnSesion.setEnabled(true);

                    if (saveLoginCheckbox.isChecked()) {
                        loginPrefsEditor.putBoolean("saveLogin", true);
                        loginPrefsEditor.putString("username", username);
                        loginPrefsEditor.putString("password", password);
                        loginPrefsEditor.commit();
                    } else {
                        loginPrefsEditor.clear();
                        loginPrefsEditor.commit();
                    }

                }

                btnSesion.setEnabled(false);

                iniciar_sesion();
            }
        });


        // Inflate the layout for this fragment
        return vista;
    }


    @Override
    public void onErrorResponse(VolleyError error) {
        Toast.makeText(getContext(), "No Se encontró el usuario " + error.toString() + txtUser.getText().toString(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onResponse(JSONObject response) {
        Toast.makeText(getContext(), "Se encontró el usuario " + txtUser.getText().toString(), Toast.LENGTH_SHORT).show();

        User usuario = new User();

        JSONArray jsonArray = response.optJSONArray("datos");
        JSONObject jsonObject = null;

        try {
            saveLogin = loginPreferences.getBoolean("saveLogin", false);
            jsonObject = jsonArray.getJSONObject(0);
            if (saveLogin == true) {
                usuario.setUser(jsonObject.optString("user"));
                usuario.setPwd(jsonObject.optString("pwd"));
                usuario.setNames(jsonObject.optString("names"));
                saveLoginCheckbox.setChecked(true);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


        Intent intencion = new Intent(getContext(), Main2Activity.class);
        intencion.putExtra(Main2Activity.nombres, usuario.getNames());
        startActivity(intencion);


    }


    void iniciar_sesion() {
        //192.168.1.66(172.29.243.3 https://alonsoh.000webhostapp.com/


       /* String url = "https://alonsoh.000webhostapp.com/sesion.php?user=" + txtUser.getText().toString() +
                "&pwd=" + txtPwd.getText().toString();
        jrq = new JsonObjectRequest(Request.Method.GET, url, null, this, this);
        rq.add(jrq);  */

        JsonObjectRequest jrq = new JsonObjectRequest(Request.Method.GET, URL, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                Log.wtf("The Response ", response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {


            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError{
                Map<String, String> params = new HashMap<>();
                params.put("Authorization", "MTQxMzE0NEB1dHAuZWR1LnBlOmthaXNlcjEyMw==");
                return params;
            }


        };
    }
}